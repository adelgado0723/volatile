-- Query 2

SELECT description
FROM COURSES
WHERE semester LIKE '%2018';


